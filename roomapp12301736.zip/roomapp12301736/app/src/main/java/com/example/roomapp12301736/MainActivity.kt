package com.example.roomapp12301736

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.roomapp12301736.model.UsuarioModel
import com.example.roomapp12301736.repositorie.UsuarioDataBase

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val usuarioDatabase = UsuarioDataBase.getDataBase(this).usuarioDAO()

        //Observe como fazemos o insert, passando uma instância de UsuarioModel, modificando os atributos:
        val retornoInsert = usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })

        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Henrique Ignacio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "José Venâncio"
            this.idade = 17
        })
        usuarioDatabase.insertUser(UsuarioModel().apply {
            this.nome = "Daniel Marcos"
            this.idade = 17
        })
        usuarioDatabase.updateUser(UsuarioModel().apply {
            this.id_usuario = 12
            this.nome = "José Venâncio"
            this.idade = 17
        })
        usuarioDatabase.deleteUser(UsuarioModel().apply {
            this.id_usuario = 12
        })

        val retornoSelectMultiplo = usuarioDatabase.getAll()//Retorna todos os registros

        for(item in retornoSelectMultiplo){
            Log.d("Retorno Múltiplo", "id_usuario: ${item.id_usuario}, nome: ${item.nome}, idade: ${item.idade}")
        }
    }
}